import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'screens/auth/login_screen.dart';
import 'screens/auth/register_screen.dart';
import 'screens/quote/quote_form_screen.dart';
import 'screens/quote/quotation_sheet_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final prefs = await SharedPreferences.getInstance();
  final userId = prefs.getInt('user_id');

  runApp(SteelQuoteApp(isLoggedIn: userId != null));
}

class SteelQuoteApp extends StatelessWidget {
  final bool isLoggedIn;

  const SteelQuoteApp({super.key, required this.isLoggedIn});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Steel Quote App',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(primarySwatch: Colors.indigo),
      initialRoute: isLoggedIn ? '/quote' : '/login',
      routes: {
        '/login': (_) => const LoginScreen(),
        '/register': (_) => const RegisterScreen(),
        '/quote': (_) => const QuoteFormScreen(),
        '/quotation_sheet': (_) => const QuotationSheetScreen(),
      },
    );
  }
}

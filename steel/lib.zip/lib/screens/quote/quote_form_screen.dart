import 'package:flutter/material.dart';
import 'package:steel_quote_app/styles/input_styles.dart';
import 'package:steel_quote_app/screens/quote/quotation_sheet_screen.dart';
import 'package:steel_quote_app/utils/logout_helper.dart';
import 'package:steel_quote_app/services/quote_service.dart';

class QuoteFormScreen extends StatefulWidget {
  const QuoteFormScreen({super.key});

  @override
  _QuoteFormScreenState createState() => _QuoteFormScreenState();
}

class _QuoteFormScreenState extends State<QuoteFormScreen> {
  final _formKey = GlobalKey<FormState>();

  List<Map<String, dynamic>> steelTypes = [];
  List<Map<String, dynamic>> widthOptions = [];
  List<Map<String, dynamic>> thicknessOptions = [];

  String? selectedSteelTypeLabel;
  int? selectedSteelTypeId;
  String? selectedWidthLabel;
  int? selectedWidthId;
  String? selectedThicknessLabel;
  int? selectedThicknessId;

  String zincLayer = '30';
  List<String> availableAddOns = ['Coils', 'Sheets', 'Bending (Roof)', 'Print', 'Oil (Shining)'];
  List<String> selectedAddOns = [];
  String quantityType = 'Net Weight';
  String coilWeight = '3~5 Tons';
  String loadingPort = 'Tianjin';
  String packingType = 'Export Packing';
  double? finalPrice;

  @override
  void initState() {
    super.initState();
    loadSteelTypes();
    loadWidths();
    loadThicknesses();
  }

  Future<void> loadSteelTypes() async {
    steelTypes = await QuoteService.fetchSteelTypes();
    setState(() {
      selectedSteelTypeLabel = steelTypes.first['label'];
      selectedSteelTypeId = steelTypes.first['id'];
    });
  }

  Future<void> loadWidths() async {
    widthOptions = await QuoteService.fetchWidths();
    setState(() {
      selectedWidthLabel = widthOptions.first['width_mm'].toString();
      selectedWidthId = widthOptions.first['id'];
    });
  }

  Future<void> loadThicknesses() async {
    thicknessOptions = await QuoteService.fetchThicknesses();
    setState(() {
      selectedThicknessLabel = thicknessOptions.first['label'].toString();
      selectedThicknessId = thicknessOptions.first['id'];
    });
  }

  Future<void> calculatePrice() async {
    final input = {
      "width_id": selectedWidthId,
      "material_id": selectedSteelTypeId,
      "thickness_id": selectedThicknessId,
      "zinc": int.tryParse(zincLayer) ?? 30,
      "coating_id": 1,
      "processing_ids": [1, 2],
      "packing_id": 1,
      "shipping_type": "FOB",
      "shipping_port_id": 2,
      "profit_type": "percent",
      "profit_value": 8,
    };

    try {
      final result = await QuoteService.calculateQuote(input);
      setState(() {
        finalPrice = result['final_rmb'];
      });
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: ${e.toString()}')),
      );
    }
  }

  Widget buildDropdown(String label, String value, List<String> items, void Function(String?) onChanged) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500)),
        const SizedBox(height: 6),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          decoration: BoxDecoration(
            border: Border.all(color: Colors.black26),
            borderRadius: BorderRadius.circular(12),
          ),
          child: DropdownButtonHideUnderline(
            child: DropdownButton<String>(
              isExpanded: true,
              value: value,
              items: items.map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
              onChanged: onChanged,
            ),
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Steel Quote Form'),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            tooltip: 'Logout',
            onPressed: () => showLogoutConfirmation(context),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Basic details', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 12),
            buildDropdown(
              'Steel Type',
              selectedSteelTypeLabel ?? '',
              steelTypes.map((e) => e['label'] as String).toList(),
              (val) => setState(() {
                selectedSteelTypeLabel = val;
                selectedSteelTypeId = steelTypes.firstWhere((e) => e['label'] == val)['id'];
              }),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: buildDropdown(
                    'Width mm',
                    selectedWidthLabel ?? '',
                    widthOptions.map((e) => e['width_mm'].toString()).toList(),
                    (val) => setState(() {
                      selectedWidthLabel = val;
                      selectedWidthId = widthOptions.firstWhere((e) => e['width_mm'].toString() == val)['id'];
                    }),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: buildDropdown(
                    'Thickness mm',
                    selectedThicknessLabel ?? '',
                    thicknessOptions.map((e) => e['label'].toString()).toList(),
                    (val) => setState(() {
                      selectedThicknessLabel = val;
                      selectedThicknessId = thicknessOptions.firstWhere((e) => e['label'].toString() == val)['id'];
                    }),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            TextFormField(
              initialValue: zincLayer,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'Zinc Layer (g/m²)'),
              onChanged: (val) => setState(() => zincLayer = val),
            ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: availableAddOns.map((addOn) {
                final isSelected = selectedAddOns.contains(addOn);
                return ChoiceChip(
                  label: Text(addOn),
                  selected: isSelected,
                  onSelected: (_) => setState(() {
                    isSelected ? selectedAddOns.remove(addOn) : selectedAddOns.add(addOn);
                  }),
                );
              }).toList(),
            ),
            const SizedBox(height: 20),
            Row(
              children: [
                Expanded(
                  child: buildDropdown('Weight Type', quantityType, ['Net Weight', 'Gross Weight'], (val) => setState(() => quantityType = val ?? quantityType)),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: buildDropdown('Coil Weight', coilWeight, ['1~3 Tons', '3~5 Tons', '5~7 Tons'], (val) => setState(() => coilWeight = val ?? coilWeight)),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: buildDropdown('Loading Port', loadingPort, ['Tianjin', 'Qingdao', 'Ningbo', 'Shanghai'], (val) => setState(() => loadingPort = val ?? loadingPort)),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: buildDropdown('Packing Type', packingType, ['Export Packing', 'Standard Packing'], (val) => setState(() => packingType = val ?? packingType)),
                ),
              ],
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: calculatePrice,
              child: const Text("Show Price"),
            ),
            if (finalPrice != null)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 16.0),
                child: Text('Final Price: ¥${finalPrice!.toStringAsFixed(2)}', style: Theme.of(context).textTheme.headlineSmall),
              ),
          ],
        ),
      ),
    );
  }
}

import 'dart:convert';
import 'package:http/http.dart' as http;

class QuoteService {
  static const String _baseUrl = 'http://10.0.2.2:8888/app/steel-backend/api/';

  static Future<Map<String, dynamic>> calculateQuote(Map<String, dynamic> input) async {
    final response = await http.post(
      Uri.parse('$_baseUrl/calculate_quote.php'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode(input),
    );
    

    if (response.statusCode == 200) {

      final data = jsonDecode(response.body);
      if (data['status'] == 'success') {
        return data['data'];
      } else {
        throw Exception(data['message'] ?? 'Calculation failed');
      }
    } else {
      throw Exception('Server error: ${response.statusCode}');
    }
  }
      // get steel types from the server
  static Future<List<Map<String, dynamic>>> fetchSteelTypes() async {
    final response = await http.get(
      Uri.parse('$_baseUrl/get_steel_types.php'));
    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      return List<Map<String, dynamic>>.from(data['data']);
    } else {
      throw Exception('Failed to load steel types');
    }
  }
      // get widths from the server
  static Future<List<Map<String, dynamic>>> fetchWidths() async {
    final response = await http.get
    (Uri.parse('$_baseUrl/get_widths.php'));
    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      return List<Map<String, dynamic>>.from(data['data']);
    } else {
      throw Exception('Failed to load widths');
    }
  }
    // get thicknesses from the server 
    static Future<List<Map<String, dynamic>>> fetchThicknesses() async {
  final response = await http.get(Uri.parse('$_baseUrl/get_thickness_list.php'));
  if (response.statusCode == 200) {
    final data = jsonDecode(response.body);
    return List<Map<String, dynamic>>.from(data['data']);
  } else {
    throw Exception('Failed to load thickness options');
  }
}

  // You will continue adding more:
  // static Future<List<Map<String, dynamic>>> fetchCoilWeights() async { ... }
  // static Future<List<Map<String, dynamic>>> fetchPackingTypes() async { ... }
  // static Future<List<Map<String, dynamic>>> fetchProcessingOptions() async { ... }
  // static Future<List<Map<String, dynamic>>> fetchShippingPorts() async { ... }
}
